package com.kwansik.vinylwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * 위젯 꾸미기: 배경 투명도 + 재생 버튼 색(프리셋 10색 + 색상/채도/밝기 슬라이더 + HEX 입력)
 * - 위젯을 길게 눌러 '설정'으로 열면 → 그 위젯만 변경
 * - 앱의 '모든 위젯 꾸미기'로 열면 → 전체 위젯에 적용
 * 창 뒤로 실제 배경화면이 보이게 해서 투명도를 눈으로 맞출 수 있게 함
 */
class ConfigActivity : Activity() {

    private val presets = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFBDBDBD.toInt(), 0xFF212121.toInt(), 0xFFFF0033.toInt(), 0xFFFF8A00.toInt(),
        0xFFFFD600.toInt(), 0xFF00C853.toInt(), 0xFF00B8D4.toInt(), 0xFF2962FF.toInt(), 0xFFD500F9.toInt()
    )

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var transparency = WidgetPrefs.DEFAULT_TRANSPARENCY
    private var color = WidgetPrefs.DEFAULT_COLOR
    private val hsv = FloatArray(3)
    private var updatingUi = false

    private lateinit var previewBg: GradientDrawable
    private val previewButtons = mutableListOf<ImageView>()
    private val swatches = mutableListOf<View>()
    private lateinit var transLabel: TextView
    private lateinit var hueBar: SeekBar
    private lateinit var satBar: SeekBar
    private lateinit var valBar: SeekBar
    private lateinit var satGradient: GradientDrawable
    private lateinit var valGradient: GradientDrawable
    private lateinit var hexInput: EditText
    private lateinit var colorChip: View

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, resultIntent())

        val id = targetId()
        transparency = WidgetPrefs.transparency(this, id)
        color = WidgetPrefs.color(this, id)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(buildPreview(), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220)))
        root.addView(ScrollView(this).apply { addView(buildPanel()) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        applyColor(color, fromHsv = false)
        updatePreview()
    }

    private fun targetId(): Int? = widgetId.takeIf { it != AppWidgetManager.INVALID_APPWIDGET_ID }

    private fun resultIntent() = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)

    // ---------- 미리보기 ----------
    private fun buildPreview(): View {
        val area = FrameLayout(this)
        val widget = FrameLayout(this)
        previewBg = GradientDrawable().apply {
            setColor(0xFF141414.toInt())
            cornerRadius = dp(24).toFloat()
        }
        widget.background = previewBg
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.vinyl_disc)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (res in intArrayOf(R.drawable.ic_prev, R.drawable.ic_play, R.drawable.ic_next)) {
            val iv = ImageView(this).apply { setImageResource(res); scaleType = ImageView.ScaleType.CENTER_INSIDE }
            previewButtons += iv
            row.addView(iv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        }
        col.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36)))
        widget.addView(col)
        area.addView(widget, FrameLayout.LayoutParams(dp(160), dp(160), Gravity.CENTER))
        return area
    }

    // ---------- 설정 패널 ----------
    private fun buildPanel(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable().apply {
                setColor(0xF21C1C1E.toInt())
                cornerRadii = floatArrayOf(dp(20).toFloat(), dp(20).toFloat(), dp(20).toFloat(), dp(20).toFloat(), 0f, 0f, 0f, 0f)
            }
        }
        if (targetId() == null) panel.addView(text("※ 모든 위젯에 한꺼번에 적용됩니다", 13f, 0xFFAAAAAA.toInt()))

        // 배경 투명도
        transLabel = text("", 16f)
        panel.addView(transLabel)
        panel.addView(SeekBar(this).apply {
            max = 100
            progress = transparency
            setOnSeekBarChangeListener(listener { p ->
                transparency = p
                updatePreview()
            })
        })

        // 버튼 색 - 프리셋
        panel.addView(space(16))
        panel.addView(text("버튼 색상", 16f))
        for (rowIdx in 0 until 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (i in 0 until 5) {
                val c = presets[rowIdx * 5 + i]
                val sw = View(this).apply {
                    tag = c
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
                    setOnClickListener { hexInput.clearFocus(); applyColor(c, fromHsv = false) }
                }
                swatches += sw
                row.addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
            }
            panel.addView(row)
        }

        // 버튼 색 - 직접 선택
        panel.addView(space(12))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("직접 선택", 16f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        colorChip = View(this)
        header.addView(colorChip, LinearLayout.LayoutParams(dp(28), dp(28)))
        panel.addView(header)

        panel.addView(text("색상", 13f, 0xFFAAAAAA.toInt()))
        hueBar = gradientBar(360, GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
            Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED)))
        panel.addView(hueBar)
        panel.addView(text("채도", 13f, 0xFFAAAAAA.toInt()))
        satGradient = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.WHITE, Color.RED))
        satBar = gradientBar(100, satGradient)
        panel.addView(satBar)
        panel.addView(text("밝기", 13f, 0xFFAAAAAA.toInt()))
        valGradient = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.BLACK, Color.RED))
        valBar = gradientBar(100, valGradient)
        panel.addView(valBar)

        hexInput = EditText(this).apply {
            hint = "#FFFFFF"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF777777.toInt())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (updatingUi) return
                    val hex = s.toString().trim().removePrefix("#")
                    if (hex.length == 6 && hex.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }) {
                        applyColor(0xFF000000.toInt() or hex.toInt(16), fromHsv = false)
                    }
                }
            })
        }
        panel.addView(hexInput)

        // 저장/취소
        panel.addView(space(16))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text = "취소"; setOnClickListener { finish() } },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply { text = "저장"; setOnClickListener { save() } },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(actions)
        return panel
    }

    private fun gradientBar(maxValue: Int, drawable: GradientDrawable) = SeekBar(this).apply {
        max = maxValue
        drawable.cornerRadius = dp(6).toFloat()
        progressDrawable = drawable
        minHeight = dp(12)
        maxHeight = dp(12)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setOnSeekBarChangeListener(listener { onHsvChanged() })
    }

    // ---------- 동작 ----------
    private fun onHsvChanged() {
        if (updatingUi) return
        hsv[0] = hueBar.progress.toFloat()
        hsv[1] = satBar.progress / 100f
        hsv[2] = valBar.progress / 100f
        hexInput.clearFocus()
        applyColor(Color.HSVToColor(hsv), fromHsv = true)
    }

    private fun applyColor(c: Int, fromHsv: Boolean) {
        color = c or 0xFF000000.toInt()
        if (!fromHsv) Color.colorToHSV(color, hsv)
        updatingUi = true
        hueBar.progress = hsv[0].roundToInt()
        satBar.progress = (hsv[1] * 100).roundToInt()
        valBar.progress = (hsv[2] * 100).roundToInt()
        if (!hexInput.hasFocus()) hexInput.setText(String.format("#%06X", color and 0xFFFFFF))
        updatingUi = false

        satGradient.colors = intArrayOf(Color.HSVToColor(floatArrayOf(hsv[0], 0f, hsv[2])),
            Color.HSVToColor(floatArrayOf(hsv[0], 1f, hsv[2])))
        valGradient.colors = intArrayOf(Color.BLACK, Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], 1f)))
        colorChip.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(2), Color.WHITE)
        }
        swatches.forEach { sw ->
            val sc = sw.tag as Int
            (sw.background as GradientDrawable).setStroke(if (sc == color) dp(3) else 0, Color.WHITE)
        }
        updatePreview()
    }

    private fun updatePreview() {
        transLabel.text = "배경 투명도  $transparency%"
        previewBg.alpha = WidgetPrefs.alphaOf(transparency)
        previewButtons.forEach { it.setColorFilter(color) }
    }

    private fun save() {
        WidgetPrefs.save(this, targetId(), transparency, color)
        WidgetUpdater.refresh(this)
        setResult(RESULT_OK, resultIntent())
        finish()
    }

    // ---------- 작은 도우미 ----------
    private fun text(s: String, size: Float, c: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(c); setPadding(0, dp(4), 0, dp(4))
    }

    private fun space(h: Int) = View(this).apply { minimumHeight = dp(h) }

    private fun listener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }
}
