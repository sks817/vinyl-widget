package com.kwansik.vinylwidget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.View
import android.widget.RemoteViews

/** 레코드 위젯 화면 만들기 (실제 위젯과 설정 화면 미리보기가 같은 코드를 씀) */
object MusicWidget {

    fun build(ctx: Context, style: WidgetStyle, label: Bitmap, playing: Boolean, status: String?): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_spin)

        rv.setInt(R.id.bg_image, "setColorFilter", WidgetPrefs.bgColor(style))
        rv.setInt(R.id.bg_image, "setImageAlpha", WidgetPrefs.alphaOf(style.transparency))
        for (btn in intArrayOf(R.id.btn_prev, R.id.btn_play, R.id.btn_next)) {
            rv.setInt(btn, "setColorFilter", style.fg)
        }

        rv.setViewVisibility(R.id.spinner, if (playing) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.static_disc, if (playing) View.GONE else View.VISIBLE)
        rv.setImageViewBitmap(R.id.label, label)

        rv.setImageViewResource(R.id.btn_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setOnClickPendingIntent(R.id.btn_prev, action(ctx, WidgetActionReceiver.ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.btn_play, action(ctx, WidgetActionReceiver.ACTION_PLAY_PAUSE, 2))
        rv.setOnClickPendingIntent(R.id.btn_next, action(ctx, WidgetActionReceiver.ACTION_NEXT, 3))
        rv.setOnClickPendingIntent(R.id.disc_area, openIntent(ctx))

        if (status != null) {
            rv.setTextViewText(R.id.status, status)
            rv.setViewVisibility(R.id.status, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.status, View.GONE)
        }
        return rv
    }

    private fun action(ctx: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, WidgetActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun openIntent(ctx: Context): PendingIntent {
        val ytm = ctx.packageManager.getLaunchIntentForPackage(MediaHelper.YTM_PACKAGE)
        val intent = if (MediaHelper.hasAccess(ctx) && ytm != null) ytm
        else Intent(ctx, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            ctx, 10, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
