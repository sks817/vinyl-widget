package com.kwansik.vinylwidget

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileNotFoundException

/** files/frames/ 안의 PNG만 읽기 전용으로 제공. 그 밖의 경로는 거부합니다. */
class FrameProvider : ContentProvider() {

    override fun onCreate() = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw SecurityException("read only")
        val base = File(context!!.filesDir, "frames").canonicalFile
        val segs = uri.pathSegments
        if (segs.size != 2) throw FileNotFoundException(uri.toString())
        val file = File(File(base, segs[0]), segs[1]).canonicalFile
        if (!file.path.startsWith(base.path + File.separator) || !file.exists()) {
            throw FileNotFoundException(uri.toString())
        }
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri) = "image/png"
    override fun query(u: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun update(u: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
    override fun delete(u: Uri, s: String?, a: Array<out String>?) = 0
}
