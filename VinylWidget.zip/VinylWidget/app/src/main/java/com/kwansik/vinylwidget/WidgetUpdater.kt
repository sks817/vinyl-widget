package com.kwansik.vinylwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import java.util.concurrent.Executors

object WidgetUpdater {

    data class NowPlaying(val trackKey: String, val art: Bitmap?, val playing: Boolean)

    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var lastKey: String? = null

    private fun snapshot(c: MediaController): NowPlaying {
        val m = c.metadata
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        return NowPlaying("$title|$artist|${art != null}", art, playing)
    }

    /** 미디어 서비스에서 호출: 곡/재생상태가 바뀔 때 */
    fun render(ctx: Context, controller: MediaController?) {
        val app = ctx.applicationContext
        val np = controller?.let { snapshot(it) }
        executor.execute { safeRender(app, np, force = false) }
    }

    /** 위젯 추가·설정 변경·앱 실행 시: 현재 상태를 직접 조회해서 강제 갱신 */
    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        executor.execute {
            val np = MediaHelper.findController(app)?.let { snapshot(it) }
            safeRender(app, np, force = true)
        }
    }

    private fun safeRender(ctx: Context, np: NowPlaying?, force: Boolean) {
        try {
            renderInternal(ctx, np, force)
        } catch (t: Throwable) {
            Log.e("VinylWidget", "render failed", t)
        }
    }

    private fun renderInternal(ctx: Context, np: NowPlaying?, force: Boolean) {
        val access = MediaHelper.hasAccess(ctx)
        val key = "${np?.trackKey}|${np?.playing}|$access"
        if (!force && key == lastKey) return   // 같은 상태면 다시 그리지 않음(배터리)

        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, SpinWidgetProvider::class.java))
        if (ids.isEmpty()) {
            lastKey = null
            return
        }
        val status = when {
            !access -> "탭해서 권한 설정"
            np == null -> "유튜브 뮤직을\n재생해 주세요"
            else -> null
        }
        val playing = np?.playing == true
        val label = LabelRenderer.draw(np?.art)
        for (id in ids) {   // 위젯마다 투명도·버튼 색이 다를 수 있어 개별 갱신
            mgr.updateAppWidget(id, build(ctx, id, label, playing, status))
        }
        lastKey = key
    }

    private fun build(ctx: Context, id: Int, label: Bitmap, playing: Boolean, status: String?): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_spin)

        // 꾸미기 설정
        rv.setInt(R.id.bg_image, "setImageAlpha", WidgetPrefs.alphaOf(WidgetPrefs.transparency(ctx, id)))
        val color = WidgetPrefs.color(ctx, id)
        for (btn in intArrayOf(R.id.btn_prev, R.id.btn_play, R.id.btn_next)) {
            rv.setInt(btn, "setColorFilter", color)
        }

        // 회전 / 정지
        rv.setViewVisibility(R.id.spinner, if (playing) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.static_disc, if (playing) View.GONE else View.VISIBLE)
        rv.setImageViewBitmap(R.id.label, label)

        // 버튼
        rv.setImageViewResource(R.id.btn_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setOnClickPendingIntent(R.id.btn_prev, action(ctx, WidgetActionReceiver.ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.btn_play, action(ctx, WidgetActionReceiver.ACTION_PLAY_PAUSE, 2))
        rv.setOnClickPendingIntent(R.id.btn_next, action(ctx, WidgetActionReceiver.ACTION_NEXT, 3))
        rv.setOnClickPendingIntent(R.id.disc_area, openIntent(ctx))

        if (status != null) {
            rv.setTextViewText(R.id.status, status)
            rv.setViewVisibility(R.id.status, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.status, View.GONE)
        }
        return rv
    }

    private fun action(ctx: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, WidgetActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** 판을 누르면: 권한 없으면 이 앱, 있으면 유튜브 뮤직 열기 */
    private fun openIntent(ctx: Context): PendingIntent {
        val ytm = ctx.packageManager.getLaunchIntentForPackage(MediaHelper.YTM_PACKAGE)
        val intent = if (MediaHelper.hasAccess(ctx) && ytm != null) ytm
        else Intent(ctx, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            ctx, 10, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
