package com.kwansik.vinylwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import java.util.concurrent.Executors

object WidgetUpdater {

    data class NowPlaying(val trackKey: String, val art: Bitmap?, val playing: Boolean)

    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var lastKey: String? = null

    private fun snapshot(c: MediaController): NowPlaying {
        val m = c.metadata
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        return NowPlaying("$title|$artist|${art != null}", art, playing)
    }

    /** 미디어 서비스에서 호출: 곡/재생상태가 바뀔 때 */
    fun render(ctx: Context, controller: MediaController?) {
        val app = ctx.applicationContext
        val np = controller?.let { snapshot(it) }
        executor.execute { safeRender(app, np, force = false) }
    }

    /** 위젯 추가 직후·앱 실행 시: 현재 상태를 직접 조회해서 강제 갱신 */
    fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        executor.execute {
            val np = MediaHelper.findController(app)?.let { snapshot(it) }
            safeRender(app, np, force = true)
        }
    }

    private fun safeRender(ctx: Context, np: NowPlaying?, force: Boolean) {
        try {
            renderInternal(ctx, np, force)
        } catch (t: Throwable) {
            Log.e("VinylWidget", "render failed", t)
        }
    }

    private fun renderInternal(ctx: Context, np: NowPlaying?, force: Boolean) {
        val access = MediaHelper.hasAccess(ctx)
        val key = "${np?.trackKey}|${np?.playing}|$access"
        if (!force && key == lastKey) return   // 같은 상태면 다시 그리지 않음(배터리)

        val mgr = AppWidgetManager.getInstance(ctx)
        val flipIds = mgr.getAppWidgetIds(ComponentName(ctx, FlipWidgetProvider::class.java))
        val spinIds = mgr.getAppWidgetIds(ComponentName(ctx, SpinWidgetProvider::class.java))
        if (flipIds.isEmpty() && spinIds.isEmpty()) {
            lastKey = null
            return
        }
        val status = when {
            !access -> "탭해서 권한 설정"
            np == null -> "유튜브 뮤직을\n재생해 주세요"
            else -> null
        }
        val playing = np?.playing == true

        if (flipIds.isNotEmpty()) {
            val version = FrameRenderer.ensureFrames(ctx, np)
            mgr.updateAppWidget(flipIds, buildFlip(ctx, version, playing, status))
        }
        if (spinIds.isNotEmpty()) {
            mgr.updateAppWidget(spinIds, buildSpin(ctx, np, playing, status))
        }
        lastKey = key
    }

    private fun buildFlip(ctx: Context, version: String, playing: Boolean, status: String?): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_flip)
        rv.removeAllViews(R.id.flipper)   // 런처가 기존 뷰에 덧붙이는 것 방지
        val count = if (playing) FrameRenderer.FRAME_COUNT else 1   // 일시정지면 1장 = 멈춤
        for (i in 0 until count) {
            val frame = RemoteViews(ctx.packageName, R.layout.widget_frame)
            frame.setImageViewUri(R.id.frame_image, FrameRenderer.uri(ctx, version, i))
            rv.addView(R.id.flipper, frame)
        }
        bindCommon(ctx, rv, playing, status)
        return rv
    }

    private fun buildSpin(ctx: Context, np: NowPlaying?, playing: Boolean, status: String?): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_spin)
        rv.setViewVisibility(R.id.spinner, if (playing) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.static_disc, if (playing) View.GONE else View.VISIBLE)
        rv.setImageViewBitmap(R.id.label, FrameRenderer.drawSpinLabel(np?.art))
        bindCommon(ctx, rv, playing, status)
        return rv
    }

    private fun bindCommon(ctx: Context, rv: RemoteViews, playing: Boolean, status: String?) {
        rv.setImageViewResource(R.id.btn_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setOnClickPendingIntent(R.id.btn_prev, action(ctx, WidgetActionReceiver.ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.btn_play, action(ctx, WidgetActionReceiver.ACTION_PLAY_PAUSE, 2))
        rv.setOnClickPendingIntent(R.id.btn_next, action(ctx, WidgetActionReceiver.ACTION_NEXT, 3))
        rv.setOnClickPendingIntent(R.id.disc_area, openIntent(ctx))
        if (status != null) {
            rv.setTextViewText(R.id.status, status)
            rv.setViewVisibility(R.id.status, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.status, View.GONE)
        }
    }

    private fun action(ctx: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, WidgetActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** 판을 누르면: 권한 없으면 설정 앱(이 앱), 있으면 유튜브 뮤직 열기 */
    private fun openIntent(ctx: Context): PendingIntent {
        val ytm = ctx.packageManager.getLaunchIntentForPackage(MediaHelper.YTM_PACKAGE)
        val intent = if (MediaHelper.hasAccess(ctx) && ytm != null) ytm
        else Intent(ctx, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(
            ctx, 10, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
