package com.kwansik.vinylwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color

enum class Kind { MUSIC, WEATHER }

/** 위젯 꾸미기 값. design은 날씨 위젯에서만 사용(1~5) */
data class WidgetStyle(val white: Boolean, val transparency: Int, val fg: Int, val design: Int)

/**
 * 위젯별 꾸미기 설정. 위젯마다 따로 저장(커버/메인 화면을 다르게 꾸밀 수 있음).
 * 개별 설정이 없으면 종류별 '전체 기본값'을 따름.
 */
object WidgetPrefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)

    fun defaults(kind: Kind) = when (kind) {
        Kind.MUSIC -> WidgetStyle(white = false, transparency = 15, fg = Color.WHITE, design = 1)
        Kind.WEATHER -> WidgetStyle(white = false, transparency = 100, fg = 0xFF161616.toInt(), design = 1)
    }

    // 음악 위젯 기본값 키는 이전 버전과 호환되도록 그대로 유지
    private fun dk(kind: Kind, f: String) = if (kind == Kind.MUSIC) "${f}_default" else "${f}_default_weather"

    fun providerOf(kind: Kind): Class<*> =
        if (kind == Kind.MUSIC) SpinWidgetProvider::class.java else WeatherWidgetProvider::class.java

    fun kindOf(ctx: Context, id: Int): Kind {
        val cls = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.className
        return if (cls == WeatherWidgetProvider::class.java.name) Kind.WEATHER else Kind.MUSIC
    }

    fun style(ctx: Context, kind: Kind, id: Int?): WidgetStyle {
        val p = sp(ctx)
        val d = defaults(kind)
        val base = WidgetStyle(
            p.getBoolean(dk(kind, "w"), d.white),
            p.getInt(dk(kind, "t"), d.transparency),
            p.getInt(dk(kind, "c"), d.fg),
            p.getInt(dk(kind, "d"), d.design)
        )
        if (id == null) return base
        return WidgetStyle(
            p.getBoolean("w_$id", base.white),
            p.getInt("t_$id", base.transparency),
            p.getInt("c_$id", base.fg),
            p.getInt("d_$id", base.design)
        )
    }

    /** id가 null이면 그 종류의 모든 위젯에 적용(개별 설정은 지우고 기본값으로 통일) */
    fun save(ctx: Context, kind: Kind, id: Int?, s: WidgetStyle) {
        val e = sp(ctx).edit()
        if (id != null) {
            e.putBoolean("w_$id", s.white).putInt("t_$id", s.transparency)
                .putInt("c_$id", s.fg).putInt("d_$id", s.design)
        } else {
            e.putBoolean(dk(kind, "w"), s.white).putInt(dk(kind, "t"), s.transparency)
                .putInt(dk(kind, "c"), s.fg).putInt(dk(kind, "d"), s.design)
            val ids = AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, providerOf(kind)))
            ids.forEach { e.remove("w_$it").remove("t_$it").remove("c_$it").remove("d_$it") }
        }
        e.apply()
    }

    fun delete(ctx: Context, ids: IntArray) {
        val e = sp(ctx).edit()
        ids.forEach { e.remove("w_$it").remove("t_$it").remove("c_$it").remove("d_$it") }
        e.apply()
    }

    /** 투명도(%) → 이미지 알파값(0~255) */
    fun alphaOf(transparency: Int): Int = ((100 - transparency) * 255 / 100).coerceIn(0, 255)

    fun bgColor(s: WidgetStyle): Int = if (s.white) Color.WHITE else 0xFF141414.toInt()
}
