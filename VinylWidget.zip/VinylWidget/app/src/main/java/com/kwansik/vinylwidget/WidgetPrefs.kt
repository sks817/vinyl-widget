package com.kwansik.vinylwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color

/**
 * 위젯별 꾸미기 설정. 위젯마다 따로 저장하므로 커버 화면·메인 화면에 다르게 둘 수 있음.
 * 개별 설정이 없으면 '전체 기본값'을 따름.
 */
object WidgetPrefs {
    const val DEFAULT_TRANSPARENCY = 15          // %  (0 = 불투명, 100 = 완전 투명)
    const val DEFAULT_COLOR = Color.WHITE

    private fun sp(ctx: Context) = ctx.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)

    fun transparency(ctx: Context, id: Int?): Int {
        val p = sp(ctx)
        val def = p.getInt("t_default", DEFAULT_TRANSPARENCY)
        return if (id == null) def else p.getInt("t_$id", def)
    }

    fun color(ctx: Context, id: Int?): Int {
        val p = sp(ctx)
        val def = p.getInt("c_default", DEFAULT_COLOR)
        return if (id == null) def else p.getInt("c_$id", def)
    }

    /** 투명도(%) → 이미지 알파값(0~255) */
    fun alphaOf(transparency: Int): Int = ((100 - transparency) * 255 / 100).coerceIn(0, 255)

    /** id가 null이면 모든 위젯에 적용(개별 설정은 지우고 기본값으로 통일) */
    fun save(ctx: Context, id: Int?, transparency: Int, color: Int) {
        val e = sp(ctx).edit()
        if (id != null) {
            e.putInt("t_$id", transparency).putInt("c_$id", color)
        } else {
            e.putInt("t_default", transparency).putInt("c_default", color)
            val ids = AppWidgetManager.getInstance(ctx)
                .getAppWidgetIds(ComponentName(ctx, SpinWidgetProvider::class.java))
            ids.forEach { e.remove("t_$it").remove("c_$it") }
        }
        e.apply()
    }

    fun delete(ctx: Context, ids: IntArray) {
        val e = sp(ctx).edit()
        ids.forEach { e.remove("t_$it").remove("c_$it") }
        e.apply()
    }
}
