package com.kwansik.vinylwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color

/** 위젯 꾸미기 값. design은 날씨 위젯에서만 사용(1~5) */
data class WidgetStyle(val white: Boolean, val transparency: Int, val fg: Int, val design: Int)

/** 위젯별 꾸미기 설정. 개별 설정이 없으면 '전체 기본값'을 따름 */
object WidgetPrefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)

    fun style(ctx: Context, id: Int?): WidgetStyle {
        val p = sp(ctx)
        val d = ModuleConfig.DEFAULT
        val base = WidgetStyle(
            p.getBoolean("w_default", d.white),
            p.getInt("t_default", d.transparency),
            p.getInt("c_default", d.fg),
            p.getInt("d_default", d.design)
        )
        if (id == null) return base
        return WidgetStyle(
            p.getBoolean("w_$id", base.white),
            p.getInt("t_$id", base.transparency),
            p.getInt("c_$id", base.fg),
            p.getInt("d_$id", base.design)
        )
    }

    /** id가 null이면 모든 위젯에 적용(개별 설정은 지우고 기본값으로 통일) */
    fun save(ctx: Context, id: Int?, s: WidgetStyle) {
        val e = sp(ctx).edit()
        if (id != null) {
            e.putBoolean("w_$id", s.white).putInt("t_$id", s.transparency)
                .putInt("c_$id", s.fg).putInt("d_$id", s.design)
        } else {
            e.putBoolean("w_default", s.white).putInt("t_default", s.transparency)
                .putInt("c_default", s.fg).putInt("d_default", s.design)
            val ids = AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, ModuleConfig.PROVIDER))
            ids.forEach { e.remove("w_$it").remove("t_$it").remove("c_$it").remove("d_$it") }
        }
        e.apply()
    }

    fun delete(ctx: Context, ids: IntArray) {
        val e = sp(ctx).edit()
        ids.forEach { e.remove("w_$it").remove("t_$it").remove("c_$it").remove("d_$it") }
        e.apply()
    }

    fun alphaOf(transparency: Int): Int = ((100 - transparency) * 255 / 100).coerceIn(0, 255)

    fun bgColor(s: WidgetStyle): Int = if (s.white) Color.WHITE else 0xFF141414.toInt()
}
