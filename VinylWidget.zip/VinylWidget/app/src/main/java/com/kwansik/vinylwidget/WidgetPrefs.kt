package com.kwansik.vinylwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.widget.RemoteViews

enum class Kind { MUSIC, WEATHER }

/** 위젯 꾸미기 값. design은 날씨 위젯에서만 사용(1~5) */
data class WidgetStyle(val white: Boolean, val transparency: Int, val fg: Int, val design: Int)

/** 위젯 종류별 고정 값 (꾸미기 화면이 이걸 보고 동작) */
object KindConfig {
    fun default(k: Kind) = when (k) {
        Kind.MUSIC -> WidgetStyle(white = false, transparency = 15, fg = Color.WHITE, design = 1)
        Kind.WEATHER -> WidgetStyle(white = false, transparency = 100, fg = 0xFF161616.toInt(), design = 1)
    }

    fun provider(k: Kind): Class<*> =
        if (k == Kind.MUSIC) SpinWidgetProvider::class.java else WeatherWidgetProvider::class.java

    fun name(k: Kind) = if (k == Kind.MUSIC) "레코드" else "날씨"
    fun colorTitle(k: Kind) = if (k == Kind.MUSIC) "버튼 색상" else "글자·아이콘 색상"
    fun colorNote(k: Kind): String? =
        if (k == Kind.WEATHER) "4. LP 재킷 · 5. 달력은 디자인 고유 색을 씁니다" else null
    fun designs(k: Kind): Array<String>? = if (k == Kind.WEATHER) WeatherWidget.DESIGN_NAMES else null

    private var label: android.graphics.Bitmap? = null

    fun preview(ctx: Context, k: Kind, style: WidgetStyle): RemoteViews = when (k) {
        Kind.MUSIC -> {
            val l = label ?: LabelRenderer.draw(null).also { label = it }
            MusicWidget.build(ctx, style, l, playing = false, status = null)
        }
        Kind.WEATHER -> WeatherWidget.build(ctx, style, WeatherStore.load(ctx))
    }

    fun refreshAll(ctx: Context, k: Kind) {
        if (k == Kind.MUSIC) {
            WidgetUpdater.refresh(ctx)
        } else {
            val app = ctx.applicationContext
            Thread { WeatherWidget.renderAll(app) }.start()
        }
    }

    fun kindOf(ctx: Context, id: Int): Kind {
        val cls = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.className
        return if (cls == WeatherWidgetProvider::class.java.name) Kind.WEATHER else Kind.MUSIC
    }
}

/** 위젯별 꾸미기 설정. 개별 설정이 없으면 종류별 '전체 기본값'을 따름 */
object WidgetPrefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)

    private fun dk(k: Kind, f: String) = if (k == Kind.MUSIC) "${f}_default" else "${f}_default_weather"

    fun style(ctx: Context, k: Kind, id: Int?): WidgetStyle {
        val p = sp(ctx)
        val d = KindConfig.default(k)
        val base = WidgetStyle(
            p.getBoolean(dk(k, "w"), d.white),
            p.getInt(dk(k, "t"), d.transparency),
            p.getInt(dk(k, "c"), d.fg),
            p.getInt(dk(k, "d"), d.design)
        )
        if (id == null) return base
        return WidgetStyle(
            p.getBoolean("w_$id", base.white),
            p.getInt("t_$id", base.transparency),
            p.getInt("c_$id", base.fg),
            p.getInt("d_$id", base.design)
        )
    }

    /** id가 null이면 그 종류의 모든 위젯에 적용(개별 설정은 지우고 기본값으로 통일) */
    fun save(ctx: Context, k: Kind, id: Int?, s: WidgetStyle) {
        val e = sp(ctx).edit()
        if (id != null) {
            e.putBoolean("w_$id", s.white).putInt("t_$id", s.transparency)
                .putInt("c_$id", s.fg).putInt("d_$id", s.design)
        } else {
            e.putBoolean(dk(k, "w"), s.white).putInt(dk(k, "t"), s.transparency)
                .putInt(dk(k, "c"), s.fg).putInt(dk(k, "d"), s.design)
            val ids = AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, KindConfig.provider(k)))
            ids.forEach { e.remove("w_$it").remove("t_$it").remove("c_$it").remove("d_$it") }
        }
        e.apply()
    }

    fun delete(ctx: Context, ids: IntArray) {
        val e = sp(ctx).edit()
        ids.forEach { e.remove("w_$it").remove("t_$it").remove("c_$it").remove("d_$it") }
        e.apply()
    }

    fun alphaOf(transparency: Int): Int = ((100 - transparency) * 255 / 100).coerceIn(0, 255)

    fun bgColor(s: WidgetStyle): Int = if (s.white) Color.WHITE else 0xFF141414.toInt()
}
