package com.kwansik.vinylwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

class WeatherWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.kwansik.vinylwidget.WEATHER_REFRESH"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_REFRESH) {   // 위젯을 누르면 즉시 갱신
            val pending = goAsync()
            WeatherFetcher.fetchAsync(context) { pending.finish() }
            return
        }
        super.onReceive(context, intent)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WeatherScheduler.schedule(context)
        val pending = goAsync()
        Thread {
            try {
                WeatherWidget.renderAll(context.applicationContext)
                if (WeatherStore.load(context).isStale()) WeatherFetcher.fetch(context.applicationContext)
            } finally {
                pending.finish()
            }
        }.start()
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        WidgetPrefs.delete(context, appWidgetIds)
    }

    override fun onDisabled(context: Context) {
        WeatherScheduler.cancel(context)
    }
}
