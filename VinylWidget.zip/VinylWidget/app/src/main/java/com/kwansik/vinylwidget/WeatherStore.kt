package com.kwansik.vinylwidget

import android.content.Context
import org.json.JSONObject
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.roundToInt

/** code = WMO 날씨 코드(Open-Meteo 표준) */
data class WeatherData(
    val temp: Double?, val min: Double?, val max: Double?,
    val code: Int?, val isDay: Boolean?, val updated: Long, val error: String?
) {
    companion object {
        val EMPTY = WeatherData(null, null, null, null, null, 0L, null)
    }

    fun isStale() = System.currentTimeMillis() - updated > 35 * 60 * 1000L

    fun cond(): String {
        val c = code ?: return "--"
        return when (c) {
            0, 1 -> "맑음"
            2 -> "구름조금"
            3 -> "흐림"
            45, 48 -> "안개"
            in 51..57 -> "이슬비"
            in 61..67, in 80..82 -> "비"
            in 71..77, 85, 86 -> "눈"
            in 95..99 -> "뇌우"
            else -> "--"
        }
    }

    fun icon(): Int {
        val day = isDay ?: LocalTime.now(ZoneId.of("Asia/Seoul")).hour.let { it in 6..18 }
        val c = code ?: return R.drawable.ic_w_cloud
        return when (c) {
            0, 1 -> if (day) R.drawable.ic_w_sun else R.drawable.ic_w_moon
            2 -> R.drawable.ic_w_partly
            in 51..67, in 80..82, in 95..99 -> R.drawable.ic_w_rain
            in 71..77, 85, 86 -> R.drawable.ic_w_snow
            else -> R.drawable.ic_w_cloud
        }
    }

    fun tempText(): String = temp?.let { "${it.roundToInt()}°" } ?: "--°"

    fun rangeText(): String =
        if (min != null && max != null) "${min.roundToInt()}° / ${max.roundToInt()}°" else ""

    fun message(): String? = if (temp == null) (error ?: "갱신 대기 중") else null
}

object WeatherStore {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("weather", Context.MODE_PRIVATE)

    private fun JSONObject.optD(k: String): Double? = if (has(k) && !isNull(k)) getDouble(k) else null
    private fun JSONObject.optI(k: String): Int? = if (has(k) && !isNull(k)) getInt(k) else null
    private fun JSONObject.optS(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null

    fun load(ctx: Context): WeatherData {
        val s = sp(ctx).getString("data2", null) ?: return WeatherData.EMPTY
        return try {
            val o = JSONObject(s)
            WeatherData(o.optD("temp"), o.optD("min"), o.optD("max"), o.optI("code"),
                if (o.has("day")) o.getBoolean("day") else null, o.optLong("updated", 0L), o.optS("error"))
        } catch (e: Exception) {
            WeatherData.EMPTY
        }
    }

    fun save(ctx: Context, d: WeatherData) {
        val o = JSONObject()
            .putOpt("temp", d.temp).putOpt("min", d.min).putOpt("max", d.max)
            .putOpt("code", d.code).putOpt("day", d.isDay).put("updated", d.updated).putOpt("error", d.error)
        sp(ctx).edit().putString("data2", o.toString()).apply()
    }

    /** 마지막으로 확인한 위치(소수 둘째 자리 ≈ 1km 단위로 반올림해 저장) */
    fun location(ctx: Context): Pair<Double, Double>? {
        val p = sp(ctx)
        if (!p.contains("lat")) return null
        return p.getFloat("lat", 0f).toDouble() to p.getFloat("lon", 0f).toDouble()
    }

    fun setLocation(ctx: Context, lat: Double, lon: Double) {
        sp(ctx).edit()
            .putFloat("lat", (Math.round(lat * 100) / 100.0).toFloat())
            .putFloat("lon", (Math.round(lon * 100) / 100.0).toFloat())
            .apply()
    }
}
