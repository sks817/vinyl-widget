package com.kwansik.vinylwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.widget.RemoteViews

/** 이 앱(레코드 위젯)만의 값. 꾸미기 화면이 이걸 보고 동작함 */
object ModuleConfig {
    val DEFAULT = WidgetStyle(white = false, transparency = 15, fg = Color.WHITE, design = 1)
    val PROVIDER: Class<*> = SpinWidgetProvider::class.java
    const val NAME = "레코드"
    const val COLOR_TITLE = "버튼 색상"
    val COLOR_NOTE: String? = null
    val DESIGNS: Array<String>? = null

    private var label: Bitmap? = null

    fun preview(ctx: Context, style: WidgetStyle): RemoteViews {
        val l = label ?: LabelRenderer.draw(null).also { label = it }
        return MusicWidget.build(ctx, style, l, playing = false, status = null)
    }

    fun refreshAll(ctx: Context) = WidgetUpdater.refresh(ctx)
}
