package com.kwansik.vinylwidget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var musicStatus: TextView
    private lateinit var weatherStatus: TextView
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        // 레코드 위젯
        root.addView(title("레코드 위젯"))
        musicStatus = body()
        root.addView(musicStatus)
        root.addView(button("알림 접근 권한 열기") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        // 날씨 위젯
        root.addView(title("날씨 위젯"))
        root.addView(body().apply { text = "날씨 정보: Open-Meteo (가입·인증키 불필요)" })
        weatherStatus = body()
        root.addView(weatherStatus)
        root.addView(button("위치 권한 허용") {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        })
        root.addView(button("위치 '항상 허용' (선택: 이동 중에도 자동 반영)") {
            if (!LocationHelper.hasPermission(this)) {
                Toast.makeText(this, "먼저 '위치 권한 허용'을 눌러 주세요", Toast.LENGTH_LONG).show()
            } else {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
            }
        })
        root.addView(button("날씨 지금 새로고침") { refreshLocationAndFetch() })

        // 위젯 추가/꾸미기
        root.addView(title("위젯"))
        root.addView(button("레코드 위젯 추가") { pin(SpinWidgetProvider::class.java) })
        root.addView(button("날씨 위젯 추가") { pin(WeatherWidgetProvider::class.java) })
        root.addView(button("레코드 위젯 모두 꾸미기") { openConfig(Kind.MUSIC) })
        root.addView(button("날씨 위젯 모두 꾸미기") { openConfig(Kind.WEATHER) })
        root.addView(body().apply {
            text = "위젯마다 다르게 꾸미려면 홈 화면에서 위젯을 길게 눌러 '설정'을 누르세요."
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val ok = MediaHelper.hasAccess(this)
        musicStatus.text = if (ok) "✅ 알림 접근 허용됨 — 유튜브 뮤직을 재생하면 판이 돌아갑니다."
        else "⚠️ 알림 접근 권한이 필요합니다. 아래 버튼에서 '레코드 위젯'을 켜 주세요."
        if (ok) {
            NotificationListenerService.requestRebind(MediaHelper.listenerComponent(this))
            WidgetUpdater.refresh(this)
        }
        WeatherScheduler.schedule(this)
        updateWeatherStatus()
        if (LocationHelper.hasPermission(this)) refreshLocationAndFetch()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            refreshLocationAndFetch()
        } else {
            updateWeatherStatus()
        }
    }

    private fun refreshLocationAndFetch() {
        weatherStatus.text = "위치 확인 및 날씨 갱신 중…"
        LocationHelper.requestCurrent(this) { fetchNow() }
    }

    private fun fetchNow() {
        weatherStatus.text = "날씨 갱신 중…"
        WeatherFetcher.fetchAsync(this) { runOnUiThread { updateWeatherStatus() } }
    }

    private fun updateWeatherStatus() {
        val d = WeatherStore.load(this)
        val lines = mutableListOf<String>()
        lines += when {
            !LocationHelper.hasPermission(this) -> "⚠️ 위치 권한이 필요합니다"
            LocationHelper.hasBackground(this) -> "✅ 위치: 항상 허용"
            else -> "✅ 위치: 앱 사용 중에만 (앱을 열 때 위치 반영)"
        }
        if (d.updated > 0) {
            val t = SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(Date(d.updated))
            lines += "마지막 갱신 $t — ${d.tempText()} ${d.cond()} ${d.rangeText()}"
        }
        d.error?.let { lines += "⚠️ $it" }
        weatherStatus.text = lines.joinToString("\n")
    }

    private fun openConfig(kind: Kind) {
        startActivity(Intent(this, ConfigActivity::class.java).putExtra(ConfigActivity.EXTRA_KIND, kind.name))
    }

    private fun pin(cls: Class<*>) {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, cls), null, null)
        } else {
            Toast.makeText(this, "홈 화면을 길게 눌러 위젯 메뉴에서 추가해 주세요", Toast.LENGTH_LONG).show()
        }
    }

    private fun title(s: String) = TextView(this).apply {
        text = s
        textSize = 20f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, pad * 2, 0, pad / 2)
    }

    private fun body() = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, pad / 2) }

    private fun button(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }
}
