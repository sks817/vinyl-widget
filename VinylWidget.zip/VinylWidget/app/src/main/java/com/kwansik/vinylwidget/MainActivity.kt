package com.kwansik.vinylwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        root.addView(status)
        root.addView(button("① 알림 접근 권한 열기") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("② 위젯 추가 — A안: 커버까지 회전") { pin(FlipWidgetProvider::class.java) })
        root.addView(button("② 위젯 추가 — B안: 무늬만 회전") { pin(SpinWidgetProvider::class.java) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val ok = MediaHelper.hasAccess(this)
        status.text = if (ok) {
            "✅ 알림 접근 권한 허용됨\n\n유튜브 뮤직을 재생하면 위젯의 레코드판이 돌아갑니다."
        } else {
            "⚠️ 알림 접근 권한이 필요합니다.\n\n①을 눌러 목록에서 '레코드 위젯'을 켜 주세요.\n" +
                "유튜브 뮤직의 곡 정보·커버를 읽고 재생 버튼을 보내는 데만 사용합니다."
        }
        if (ok) {
            NotificationListenerService.requestRebind(MediaHelper.listenerComponent(this))
            WidgetUpdater.refresh(this)
        }
    }

    private fun button(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }

    private fun pin(cls: Class<*>) {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, cls), null, null)
        } else {
            Toast.makeText(this, "홈 화면을 길게 눌러 위젯 메뉴에서 추가해 주세요", Toast.LENGTH_LONG).show()
        }
    }
}
