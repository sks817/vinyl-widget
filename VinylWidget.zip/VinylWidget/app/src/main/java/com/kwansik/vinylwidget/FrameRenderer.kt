package com.kwansik.vinylwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

object FrameRenderer {
    const val FRAME_COUNT = 24          // 15도 간격. 늘리면 부드럽지만 런처 메모리↑
    private const val SIZE = 300        // 프레임 한 장 크기(px)
    private const val FLIP_LABEL_RATIO = 0.72f  // A안: 커버가 판의 72%를 덮음
    private const val SPIN_LABEL_RATIO = 0.62f  // B안: 무늬가 보이도록 62% (vinyl_disc.xml과 맞춤)

    fun uri(ctx: Context, version: String, index: Int): Uri =
        Uri.parse("content://${ctx.packageName}.frames/$version/$index.png")

    /** 곡이 바뀔 때만 24장 프레임을 새로 만들고, 같은 곡이면 재사용 */
    fun ensureFrames(ctx: Context, np: WidgetUpdater.NowPlaying?): String {
        val version = if (np == null) "default" else "t" + Integer.toHexString(np.trackKey.hashCode())
        val root = File(ctx.filesDir, "frames")
        val dir = File(root, version)
        if (File(dir, "${FRAME_COUNT - 1}.png").exists()) {
            dir.setLastModified(System.currentTimeMillis())
            return version
        }
        dir.mkdirs()
        val disc = drawDisc(np?.art)
        val frame = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(frame)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        for (i in 0 until FRAME_COUNT) {
            frame.eraseColor(Color.TRANSPARENT)
            canvas.save()
            canvas.rotate(360f * i / FRAME_COUNT, SIZE / 2f, SIZE / 2f)
            canvas.drawBitmap(disc, 0f, 0f, paint)
            canvas.restore()
            val tmp = File(dir, "$i.png.tmp")
            FileOutputStream(tmp).use { frame.compress(Bitmap.CompressFormat.PNG, 100, it) }
            tmp.renameTo(File(dir, "$i.png"))
        }
        disc.recycle()
        frame.recycle()
        cleanup(root, version)
        return version
    }

    /** B안용: 투명 배경 위에 원형 커버만 그린 이미지 */
    fun drawSpinLabel(art: Bitmap?): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        drawLabel(Canvas(bmp), art, SIZE / 2f, SIZE / 2f * SPIN_LABEL_RATIO)
        return bmp
    }

    private fun drawDisc(art: Bitmap?): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = SIZE / 2f
        val r = SIZE / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        p.color = 0xFF111111.toInt()
        c.drawCircle(cx, cx, r, p)

        // 레코드 홈
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        var gr = r * 0.96f
        var toggle = false
        while (gr > r * FLIP_LABEL_RATIO) {
            p.color = if (toggle) 0xFF242424.toInt() else 0xFF1A1A1A.toInt()
            c.drawCircle(cx, cx, gr, p)
            gr -= 2.5f
            toggle = !toggle
        }
        p.color = 0xFF3A3A3A.toInt()
        p.strokeWidth = 2f
        c.drawCircle(cx, cx, r - 1f, p)

        drawLabel(c, art, cx, r * FLIP_LABEL_RATIO)
        return bmp
    }

    private fun drawLabel(c: Canvas, art: Bitmap?, cx: Float, lr: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (art != null) {
            val src = if (art.config == Bitmap.Config.HARDWARE) art.copy(Bitmap.Config.ARGB_8888, false) else art
            // 정사각형이 아닌 커버는 가운데를 잘라 원에 맞춤(center-crop)
            val side = min(src.width, src.height).toFloat()
            val left = (src.width - side) / 2f
            val top = (src.height - side) / 2f
            val scale = (lr * 2f) / side
            val m = Matrix().apply {
                setScale(scale, scale)
                postTranslate(cx - lr - left * scale, cx - lr - top * scale)
            }
            p.shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply { setLocalMatrix(m) }
            c.drawCircle(cx, cx, lr, p)
            p.shader = null
        } else {
            p.color = 0xFFB23A2E.toInt()
            c.drawCircle(cx, cx, lr, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = 0x66000000
        c.drawCircle(cx, cx, lr, p)
        p.style = Paint.Style.FILL
        p.color = 0xFF0D0D0D.toInt()
        c.drawCircle(cx, cx, SIZE * 0.02f, p)   // 가운데 구멍
    }

    private fun cleanup(root: File, current: String) {
        val dirs = root.listFiles { f -> f.isDirectory && f.name != "default" && f.name != current } ?: return
        dirs.sortedByDescending { it.lastModified() }.drop(3).forEach { it.deleteRecursively() }
    }
}
