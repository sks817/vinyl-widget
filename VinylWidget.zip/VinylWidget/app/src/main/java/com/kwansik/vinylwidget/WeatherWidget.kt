package com.kwansik.vinylwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId

/** 날씨·날짜 위젯. 그림을 누르면 기본 캘린더 앱, 아래 날씨 줄을 누르면 새로고침 */
object WeatherWidget {

    val DESIGN_NAMES = arrayOf("LP 재킷", "불 켜진 텐트", "밤하늘 원", "큰 날짜 + 텐트", "미니멀", "다이얼", "달력")

    fun renderAll(ctx: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, WeatherWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val data = WeatherStore.load(ctx)
            for (id in ids) {
                val style = WidgetPrefs.style(ctx, Kind.WEATHER, id)
                val (w, h) = WidgetGeom.sizeDp(mgr, id)
                mgr.updateAppWidget(id, build(ctx, style, data, w, h))
            }
            scheduleMidnight(ctx)
        } catch (t: Throwable) {
            Log.e("VinylWidget", "weather render failed", t)
        }
    }

    fun build(ctx: Context, style: WidgetStyle, d: WeatherData, wDp: Float = 170f, hDp: Float = 170f): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.weather_canvas)
        rv.setInt(R.id.bg_image, "setColorFilter", WidgetPrefs.bgColor(style))
        rv.setInt(R.id.bg_image, "setImageAlpha", WidgetPrefs.alphaOf(style.transparency))
        val scene = WeatherScene(ctx, wDp, hDp, style.fg)
        scene.draw(style.design.coerceIn(1, DESIGN_NAMES.size), d)
        rv.setImageViewBitmap(R.id.w_canvas, scene.bitmap)
        rv.setOnClickPendingIntent(R.id.w_tap_calendar, calendarIntent(ctx))
        rv.setOnClickPendingIntent(R.id.w_tap_refresh, refreshIntent(ctx))
        return rv
    }

    /** 폰에서 '기본 캘린더'로 지정된 앱을 엶 (삼성 캘린더, 구글 캘린더 등) */
    private fun calendarIntent(ctx: Context): PendingIntent {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, 21, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun refreshIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 20,
            Intent(ctx, WeatherWidgetProvider::class.java).setAction(WeatherWidgetProvider.ACTION_REFRESH),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** 날짜가 그림 안에 들어가므로, 자정 직후 한 번 다시 그리도록 예약 */
    private fun scheduleMidnight(ctx: Context) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val next = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 60_000L
            val pi = PendingIntent.getBroadcast(
                ctx, 30,
                Intent(ctx, WeatherWidgetProvider::class.java).setAction(WeatherWidgetProvider.ACTION_RENDER),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
        } catch (e: Exception) {
            Log.e("VinylWidget", "midnight alarm failed", e)
        }
    }
}
