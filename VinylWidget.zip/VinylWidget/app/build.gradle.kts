plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kwansik.vinylwidget"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kwansik.vinylwidget"
        minSdk = 31          // Android 12 이상 (폴드 기기는 모두 해당)
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    // 빌드할 때마다 같은 서명키를 쓰도록 고정 → 새 버전을 기존 앱 위에 바로 덮어 설치 가능
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
