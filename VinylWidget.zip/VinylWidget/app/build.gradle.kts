plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.kwansik.vinylwidget"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kwansik.vinylwidget"
        minSdk = 31          // Android 12 이상 (폴드 기기는 모두 해당)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
