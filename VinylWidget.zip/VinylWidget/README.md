# 레코드 위젯 / 레코드 날씨 (앱 2개)

- app-debug.apk     → '레코드 위젯' (유튜브 뮤직 레코드판). 권한: 알림 접근만
- weather-debug.apk → '레코드 날씨' (날씨·날짜 5종). 권한: 인터넷 + 대략적 위치만

GitHub의 .github/workflows/build.yml 내용을 .github/workflows/build.yml.txt 내용으로 한 번 교체해야
두 APK가 모두 Releases에 올라갑니다.
