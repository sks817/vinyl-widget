package com.kwansik.recordweather

import android.content.Context
import android.widget.RemoteViews

/** 이 앱(레코드 날씨)만의 값. 꾸미기 화면이 이걸 보고 동작함 */
object ModuleConfig {
    val DEFAULT = WidgetStyle(white = false, transparency = 100, fg = 0xFF161616.toInt(), design = 1)
    val PROVIDER: Class<*> = WeatherWidgetProvider::class.java
    const val NAME = "날씨"
    const val COLOR_TITLE = "글자·아이콘 색상"
    val COLOR_NOTE: String? = "4. LP 재킷 · 5. 달력은 디자인 고유 색을 씁니다"
    val DESIGNS: Array<String>? = WeatherWidget.DESIGN_NAMES

    fun preview(ctx: Context, style: WidgetStyle): RemoteViews =
        WeatherWidget.build(ctx, style, WeatherStore.load(ctx))

    fun refreshAll(ctx: Context) {
        val app = ctx.applicationContext
        Thread { WeatherWidget.renderAll(app) }.start()
    }
}
