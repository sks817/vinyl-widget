package com.kwansik.recordweather

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        root.addView(status)
        root.addView(button("① 위치 권한 허용") {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        })
        root.addView(button("② 홈 화면에 날씨 위젯 추가") { pin() })
        root.addView(button("③ 모든 날씨 위젯 꾸미기 (디자인·배경·색)") {
            startActivity(Intent(this, ConfigActivity::class.java))
        })
        root.addView(button("날씨 지금 새로고침") { refreshLocationAndFetch() })
        root.addView(TextView(this).apply {
            textSize = 13f
            setPadding(0, pad, 0, 0)
            text = "날씨 정보: Open-Meteo (가입·인증키 불필요)\n" +
                "위치는 이 앱을 열 때 갱신됩니다. 다른 지역으로 이동하면 앱을 한 번 열어 주세요.\n" +
                "위젯마다 다르게 꾸미려면 위젯을 길게 눌러 '설정'을 누르세요."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        WeatherScheduler.schedule(this)
        updateStatus()
        if (LocationHelper.hasPermission(this)) refreshLocationAndFetch()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            refreshLocationAndFetch()
        } else {
            updateStatus()
        }
    }

    private fun refreshLocationAndFetch() {
        status.text = "위치 확인 및 날씨 갱신 중…"
        LocationHelper.requestCurrent(this) {
            WeatherFetcher.fetchAsync(this) { runOnUiThread { updateStatus() } }
        }
    }

    private fun updateStatus() {
        val d = WeatherStore.load(this)
        val lines = mutableListOf<String>()
        lines += if (LocationHelper.hasPermission(this)) "✅ 위치 권한 허용됨" else "⚠️ 위치 권한이 필요합니다 (①)"
        if (d.updated > 0) {
            val t = SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(Date(d.updated))
            lines += "마지막 갱신 $t — ${d.tempText()} ${d.cond()} ${d.rangeText()}"
        }
        d.error?.let { lines += "⚠️ $it" }
        status.text = lines.joinToString("\n")
    }

    private fun button(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }

    private fun pin() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, WeatherWidgetProvider::class.java), null, null)
        } else {
            Toast.makeText(this, "홈 화면을 길게 눌러 위젯 메뉴에서 추가해 주세요", Toast.LENGTH_LONG).show()
        }
    }
}
