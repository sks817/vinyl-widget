package com.kwansik.recordweather

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.Log
import android.widget.RemoteViews
import kotlin.math.cos
import kotlin.math.sin

/** 날씨·날짜 위젯 화면 (디자인 1~5). 날짜는 TextClock이라 자정에 자동으로 바뀜 */
object WeatherWidget {

    private val LAYOUTS = intArrayOf(
        R.layout.weather_1, R.layout.weather_2, R.layout.weather_3, R.layout.weather_4, R.layout.weather_5
    )
    val DESIGN_NAMES = arrayOf("미니멀", "쌍둥이 판", "다이얼", "LP 재킷", "달력")

    fun renderAll(ctx: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, WeatherWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val data = WeatherStore.load(ctx)
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx, WidgetPrefs.style(ctx, id), data))
            }
        } catch (t: Throwable) {
            Log.e("VinylWidget", "weather render failed", t)
        }
    }

    fun build(ctx: Context, style: WidgetStyle, d: WeatherData): RemoteViews {
        val design = style.design.coerceIn(1, 5)
        val rv = RemoteViews(ctx.packageName, LAYOUTS[design - 1])
        rv.setInt(R.id.bg_image, "setColorFilter", WidgetPrefs.bgColor(style))
        rv.setInt(R.id.bg_image, "setImageAlpha", WidgetPrefs.alphaOf(style.transparency))

        val fg = style.fg
        val msg = d.message()
        val cond = msg ?: d.cond()
        val range = d.rangeText()
        val condWithRange = if (msg == null && range.isNotEmpty()) "$cond · $range" else cond
        rv.setTextViewText(R.id.w_temp, d.tempText())

        when (design) {
            1 -> {
                rv.setImageViewResource(R.id.w_icon, d.icon())
                rv.setTextViewText(R.id.w_cond, condWithRange)
                tint(rv, fg, R.id.w_icon, R.id.w_divider)
                textColor(rv, fg, R.id.w_date, R.id.w_day, R.id.w_temp, R.id.w_cond)
            }
            2 -> {
                rv.setImageViewResource(R.id.w_icon, d.icon())
                rv.setTextViewText(R.id.w_cond, cond)
                tint(rv, fg, R.id.w_icon)
                textColor(rv, fg, R.id.w_temp, R.id.w_cond)
            }
            3 -> {
                rv.setImageViewBitmap(R.id.w_dial, drawDial(fg, d.min, d.max, d.temp))
                rv.setTextViewText(R.id.w_cond, if (msg == null && range.isNotEmpty()) "$cond · ${range.replace(" ", "")}" else cond)
                textColor(rv, fg, R.id.w_temp, R.id.w_cond, R.id.w_date)
            }
            4 -> {   // 재킷 안쪽은 고유 색(어두운 재킷 + 밝은 글자)
                rv.setImageViewResource(R.id.w_icon, d.icon())
                rv.setTextViewText(R.id.w_cond, condWithRange)
                tint(rv, 0xFFF2C14E.toInt(), R.id.w_icon)
            }
            5 -> {   // 종이 달력은 고유 색
                rv.setImageViewResource(R.id.w_icon, d.icon())
                rv.setTextViewText(R.id.w_cond, msg ?: range.ifEmpty { cond })
                tint(rv, 0xFFB23A2E.toInt(), R.id.w_icon)
            }
        }
        rv.setOnClickPendingIntent(android.R.id.background, refreshIntent(ctx))
        return rv
    }

    private fun tint(rv: RemoteViews, color: Int, vararg ids: Int) {
        for (id in ids) rv.setInt(id, "setColorFilter", color)
    }

    private fun textColor(rv: RemoteViews, color: Int, vararg ids: Int) {
        for (id in ids) rv.setTextColor(id, color)
    }

    private fun refreshIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 20,
            Intent(ctx, WeatherWidgetProvider::class.java).setAction(WeatherWidgetProvider.ACTION_REFRESH),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** 온도 다이얼: 270° 눈금에 -10~40℃를 펼치고, 오늘 최저~최고 구간과 현재 기온 점을 표시 */
    private fun drawDial(fg: Int, min: Double?, max: Double?, cur: Double?): Bitmap {
        val size = 300
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = size / 2f
        val r = 130f
        val oval = RectF(cx - r, cx - r, cx + r, cx + r)
        fun angle(t: Double) = 135f + (((t.coerceIn(-10.0, 40.0) + 10.0) / 50.0) * 270.0).toFloat()

        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        p.color = fg
        p.alpha = 64
        p.strokeWidth = 8f
        c.drawArc(oval, 135f, 270f, false, p)

        if (min != null && max != null) {
            p.color = fg
            p.strokeWidth = 12f
            val a1 = angle(min)
            val a2 = angle(max)
            c.drawArc(oval, a1, (a2 - a1).coerceAtLeast(2f), false, p)
        }
        if (cur != null) {
            val a = Math.toRadians(angle(cur).toDouble())
            val x = cx + r * cos(a).toFloat()
            val y = cx + r * sin(a).toFloat()
            val light = Color.luminance(fg) < 0.5f
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (light) 0xFFFAF9F5.toInt() else 0xFF161616.toInt()
            }
            c.drawCircle(x, y, 13f, fill)
            p.color = fg
            p.strokeWidth = 5f
            c.drawCircle(x, y, 13f, p)
        }
        return bmp
    }
}
